package mycars;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car
{
	Engine engine;
	@Autowired
	Car(Engine engine) {
		this.engine = engine;
		System.out.println("Car(Engine)");
	}
	void startCar() {
		System.out.println("Car started...");
	}

}