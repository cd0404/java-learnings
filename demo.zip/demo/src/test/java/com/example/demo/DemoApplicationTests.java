package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Account;
import com.example.demo.repository.AccountRepository;

@SpringBootTest
class DemoApplicationTests {
	@Autowired
	AccountRepository accountRepository;
	@Autowired
	Account account;
	@Test
	public void insertAccountTest() {
		Assertions.assertTrue(accountRepository!=null);
		System.out.println("Account repository is ready");
		Assertions.assertTrue(account!=null);
		System.out.println("Acc object ready");
		account.setAccountNumber(101);
		account.setAccountName("jack");
		account.setAccountBalance(500000);
		accountRepository.save(account);
		System.out.println("Account object is persisted");
	}
	

	@Test
	void contextLoads() {
		System.out.println("pass1");
		System.out.println("pass2");
		System.out.println("pass3");
		System.out.println("pass4");
		
		
	}

}
