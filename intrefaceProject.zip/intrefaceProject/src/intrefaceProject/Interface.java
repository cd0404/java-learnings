package intrefaceProject;

public class Interface {
	public static void main(String[] args) {
		Guitar guitar=new Guitar();
		guitar.use();
		guitar.tuneString();
		guitar.pluck();
		
	}

}
interface Instrument{
	void use();
}
abstract class SurgicalInstrument implements Instrument{
	abstract void sterilize();
	
}abstract class ECGInstrument extends SurgicalInstrument{
	abstract void count();
	
}

class ECG extends  ECGInstrument{
	@Override
	public void use() {
		System.out.println("measuring heart beat ecg...");
	}
	@Override
	void sterilize() {
		System.out.println("...");
	}
	void bow() {
		System.out.println("bow violin");
	}
	@Override
	void count() {
		System.out.println("measuring value")
		
	}
}