package mycars;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Piston {
	String type;
	
	Piston(@Value("Twin spark") String type) {
		this.type = type;
		System.out.println("Piston(String)");

	}
	void firePiston() {
		System.out.println("Piston fired...");
	}
}