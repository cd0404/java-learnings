package dao;//this is interface after pojo that is tables create this

public interface Accountdao {//poji
//5 methods update,insert,select,delete
//crud
	void insertAccount(Account acc);
	void selectAccount(int accno);
	void selectAllAccount();
	void updateAccount(Account acc);
	void deleteAccount(int accno);
}
//in spring we dont nned to write this above its alreday there in it
//public interface Accountdao extends Jpa