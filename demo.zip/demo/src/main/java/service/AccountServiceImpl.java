package service;

 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.repository.AccountRepository;
 
@Service
public class AccountServiceImpl implements AccountService {
 @Autowired AccountRepository accountrepository;
 
	
	@Override
	public float findOutTotalBalanceOfHolderNameStartingWith(String hint) {
		// TODO Auto-generated method stub
		return accountrepository.getSumOfBalanceWhereNameStartingWith1(hint);
	}

	@Override
	public List<Account> findOutTotalBalanceOfHolderNameEndingWith(String hint) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> findOutListOfAccountsWithBalanceGreaterThan(int balance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int findOutTheTotalLiabilityOfTheAccounts() {
		List<Account> accList = accountrepository.findAll();
		int totalLiability=0;
		for (Account account : accList) {
			totalLiability+=account.getAccountBalance();
		}
		return totalLiability;
		
//		int totalLiability=accountrepository.findAll();
//		return totalLiability;
	}

	@Override
	public List<Account> findOutAccountsNumberGreaterThan(int acno) {
		// TODO Auto-generated method stub
		return null;
	}

}
