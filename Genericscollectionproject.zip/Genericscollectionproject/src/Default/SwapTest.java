package Default;

public class SwapTest {
	public static void main(String[] args) {
		Anypair intpair=new Anypair(10,20);
		intpair.showpair();
		intpair.swap();
		intpair.showpair();
//		System.out.println("x: "+x);
//		System.out.println("y : "+y);
//		swap(x,y);
//		
//		
//	}
//	public static void swap(int x,int y) {
//		int temp=x;
//		x=y;
//		y=temp;
//	}
}}
class Anypair<T>{
	T x;
	T y;
	Anypair(T x,T y){
		this.x=x;
		this.y=y;
	}
	void showpair() {
		System.out.println("x:  "+x);
		System.out.println("y : "+y);
		
	}
	public void swap() {
		T temp=x;
		x=y;
		y=temp;
	}
}

class Flaotpair{
float x;
float y;
Flaotpair(float x,float y){
	this.x=x;
	this.y=y;
}
void showpair() {
	System.out.println("x:  "+x);
	System.out.println("y : "+y);
	
}
public void swap() {
	float temp=x;
	x=y;
	y=temp;
}
}
