package kites;

public class Abstract {
	public static void main(String[] args) {
//		GeometricalShape shape;
		Square sq=new Square(55);
		sq.draw();
//		Rectangle rect =new Rectangle(30,40)
	}
	
}
abstract class GeometricalShape{
	abstract void draw();//partial /incomplete/abstract contract of a class
}
class Square extends GeometricalShape{
	int side;
	Square(int s){side = s;}
	void draw() {
		System.out.println("square s drawn "+side);
	}
	
}
//class Rectangle extends Square{
//	void draw() {
//		
//	}
//}