package service;

public class CompositionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
class SavingsAccount{
	void withdraw(float amt) {
		System.out.println("Savings withdraw"+amt);
		
	}
}class ServerMachine{
	 
}
