package service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;


@Service
public interface AccountService {

	float  findOutTotalBalanceOfHolderNameStartingWith(String hint);
	List<Account> findOutTotalBalanceOfHolderNameEndingWith(String hint);
	List<Account> findOutListOfAccountsWithBalanceGreaterThan(int balance);
	int           findOutTheTotalLiabilityOfTheAccounts();
	List<Account> findOutAccountsNumberGreaterThan(int acno);
	
}
