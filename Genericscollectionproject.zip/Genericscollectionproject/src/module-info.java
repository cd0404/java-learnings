/**
 * 
 */
/**
 * 
 */
module Genericscollectionproject {
}