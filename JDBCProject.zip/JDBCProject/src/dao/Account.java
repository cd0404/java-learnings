package dao;

public class Account {
	public Account() {
		System.out.println("Account() ctor");
	}
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public int getAge_of_acc() {
		return age_of_acc;
	}
	public void setAge_of_acc(int age_of_acc) {
		this.age_of_acc = age_of_acc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private int acc_no;
	private String name;
	private int age_of_acc;
	
}
