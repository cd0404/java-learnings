package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import service.AccountService;
@SpringBootTest
public class AccountServiceTest {
	@Autowired AccountService accountService;
	@Test public void showSumSpentonstartwithtest() {
		Assertions.assertTrue(accountService!=null);
		float sum=accountService.findOutTotalBalanceOfHolderNameStartingWith("S%");
		System.out.println("sum:  "+sum);
		
	}
}
