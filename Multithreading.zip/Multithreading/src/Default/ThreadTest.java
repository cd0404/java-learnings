//package Default;
//
//public class ThreadTest {
// public static void main(String[] args) {
//	 Car car=new Car("Skoda");
//	 Bike bike =new Bike("tPulsar");
//	 Train train=new Train("Vande Bharat");
////	 Car car2=new Car("Maruti");
////	 Car car3=new Car("Kia");
//	 Thread t1=new Thread(car);
//	 Thread t2=new Thread(bike);
//	 Thread t3=new Thread(train);
//	 t1.start();
////	 car2.start();
////	 car3.start();
//	 t2.start();
//	 t3.start();
////	 car.run();
////	 train.run();
////	 bike.run();
//
// }
//}
//class Vehicle{
//	
//}
//class Car extends Vehicle implements Runnable{//Thread -->start()
//	String model;
//	Car(String model){
//		this.model=model;
//	}
//	public void run() {
//		for (int i=0;i<20;i++) {
//			System.out.println("car running "+model+"  "+i);
//		}
//	}
//}
//class Bike extends Vehicle implements Runnable{
//	String model;
//	Bike(String model){
//		this.model=model;
//	}
//	public void run() { //runnable
//		for (int i=0;i<=20;i++) {
//			System.out.println("bike running "+model+"  "+i);
//		}
//	}
//}
//class Train extends Vehicle implements Runnable{
//	String model;
//	Train(String model){
//		this.model=model;
//	}
//	public void run() {
//		for (int i=0;i<=20;i++) {
//			System.out.println("train running "+model+"  "+i);
//		}
//	}
//
////class Car extends Vehicle {//Thread -->start()
////	String model;
////	Car(String model){
////		this.model=model;
////	}
////	public void run() {
////		for (int i=0;i<=20;i++) {
////			System.out.println("car running "+model+"  "+i);
////		}
////	}
////}
////class Bike extends Vehicle{
////	String model;
////	Bike(String model){
////		this.model=model;
////	}
////	public void run() { //runnable
////		for (int i=0;i<=20;i++) {
////			System.out.println("bike running "+model+"  "+i);
////		}
////	}
////}
////class Train extends Vehicle{
////	String model;
////	Train(String model){
////		this.model=model;
////	}
////	public void run() {
////		for (int i=0;i<=20;i++) {
////			System.out.println("train running "+model+"  "+i);
////		}
////	}
//}