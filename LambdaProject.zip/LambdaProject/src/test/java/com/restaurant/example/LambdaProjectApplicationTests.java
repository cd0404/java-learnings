package com.restaurant.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambdaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
