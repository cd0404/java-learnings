package Default;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectTest {
	 public static void main(String[] args) {
		 try {
			System.out.println("loading");
			 DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			 System.out.println("loaded");
			 System.out.println("connected");
			 Connection conn=DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb");
			 Statement sqlStatement=conn.createStatement();
			 Scanner scanner=new Scanner(System.in);
			 System.out.print("enter acc no  ");
			 int accountnumber=scanner.nextInt();
			 ResultSet resultset=sqlStatement.executeQuery("Select * from Account_tbl"+"where ACC_NO="+accountnumber);
			 while(resultset.next()) {
				 System.out.println(resultset.getInt(1));
				  
			 }
			 resultset.close();
			 sqlStatement.close();
			 conn.close();
			 System.out.println("conn closed");
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
		 }
		 
	 }

