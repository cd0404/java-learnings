package Default;

public class Testcheckexeception {
	public static void main(String[] args) throws Exception{
		System.out.println("line 1....");
		if (Math.random()%10>0.95) {
			throw new Exception("some problem  ..");
		}
	}
}
//public class Testcheckexeception {
//	public static void main(String[] args) //throws Exception{
//		System.out.println("line 1....");
//		if (Math.random()%10>0.95) {
//			throw new RuntimeException("some problem  ..");
//		}
//	}
//}