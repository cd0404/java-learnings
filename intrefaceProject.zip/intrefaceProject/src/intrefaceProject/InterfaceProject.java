package intrefaceProject;

public class InterfaceProject {
	public static void main(String[] args) {
		Guitar guitar=new Guitar();
		guitar.use();
		guitar.tuneString();
		guitar.pluck();
		
		Violin violin=new Violin();
		violin.use();
		violin.tuneString();
		violin.bow();
		
	}
}
//interface A{
//	void fun(); //declared /by default it is public and abstract
//}
//class B{
//	void foo() {
//		
//	}
//}
//class C extends B implements A{
//	public void fun() {
//		//mandatory implemnetation
//	}
//}
interface Instrument{
	void use();
}
abstract class MusicalInstrument implements Instrument{
	abstract void play();
	
}abstract class StringBasedMusicalInstrument extends MusicalInstrument{
	abstract void tuneString();
	
}

class Guitar extends StringBasedMusicalInstrument{
	@Override
	public void use() {
		System.out.println("playing Guitar...");
	}
	@Override
	void tuneString() {
		System.out.println("tuning strings of guitar");
	}
	void pluck() {
		System.out.println("plucking guitar");
	}
	@Override
	void play() {
		System.out.println("playing guitar");// TODO Auto-generated method stub
		
	}
}
class Violin extends StringBasedMusicalInstrument{
	@Override
	public void use() {
		System.out.println("playing violin...");
	}
	@Override
	void tuneString() {
		System.out.println("tuning strings of violin");
	}
	void bow() {
		System.out.println("bow violin");
	}
	@Override
	void play() {
		System.out.println("playing violin");
		
	}
}