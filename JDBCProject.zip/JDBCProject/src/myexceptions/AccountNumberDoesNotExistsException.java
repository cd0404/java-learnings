package myexceptions;

public class AccountNumberDoesNotExistsException extends RuntimeException{
		public AccountNumberDoesNotExistsException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
		
	}

