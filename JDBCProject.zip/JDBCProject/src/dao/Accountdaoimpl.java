package dao;

public class Accountdaoimpl implements Accountdao {

	@Override
	public void insertAccount(Account acc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void selectAccount(int accno) {
		// TODO Auto-generated method stub

	}

	@Override
	public void selectAllAccount() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccount(Account acc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAccount(int accno) {
		// TODO Auto-generated method stub

	}

}
