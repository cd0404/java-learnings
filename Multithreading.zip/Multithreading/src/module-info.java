/**
 * 
 */
/**
 * 
 */
module Multithreading {
	requires java.desktop;
}