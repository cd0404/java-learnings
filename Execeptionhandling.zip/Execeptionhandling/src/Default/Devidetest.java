package Default;

public class Devidetest {
	public static void main(String[] args) {
		System.out.println("start");
		Calculator calci=new Calculator();
		calci.divide(10,5);
		calci.divide(10, 2);
		try {
		calci.divide(210, 0);}
		catch(ArithmeticException e) {
			System.out.println("error"+e.getMessage());
		}
		calci.divide(50, 3);
		calci.divide(50, 8);
		try
		{
			calci.divide("10", "abc");
		}
		catch(NumberFormatException e) {
			System.out.println("Please supply numeric value : "+e.getMessage());
		}
		catch(RuntimeException e) {
			System.out.println("some problem 1 ");
		}
		catch(Exception e) {
			System.out.println("some problem2")
		}
	
	}
}
class Calculator{
	void divide(int num,int deno) {
		System.out.println("divide started");
		System.out.println("num: "+num);
		System.out.println("deno: "+deno);
		int div=num/deno;
		System.out.println("div: "+div);
		System.out.println("Done");	
	}
}
