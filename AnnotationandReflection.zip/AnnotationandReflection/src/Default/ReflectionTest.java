package Default;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ReflectionTest {
 public static void main(String[] args) {
	 WashingMachine wash=new WashingMachine();
	 Class theMirror=wash.getClass();
	 Method methods[]=theMirror.getMethods();
	 for (Method method :methods){
		 System.out.println("methods  :"+method.getName());
	 }
 Constructor ctor[]=theMirror.getDeclaredConstructors();
 for (Constructor contructor:ctor) {
	 System.out.println("Constructor:"+contructor);
 }
 }}
