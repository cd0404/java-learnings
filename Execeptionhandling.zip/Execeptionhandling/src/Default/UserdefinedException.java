package Default;

public class UserdefinedException {
	public static void main(String[] args) {
		try {
			Sedancar sedancar=new Sedancar("Skoda");
			sedancar.startTheCar();
		}
		catch(RuntimeException e){
			System.out.println("Some car prob:"+e.getMessage());
		
		}
		catch(CarKeynotfoundex carkeyex) {
			System.out.println("car problem"+carkeyex.getMessage());
			
		}System.out.println("End main");
	}
}
class Car{
	
}
class Sedancar extends Car{
	boolean carKeyFound=false;
	Sedancar(String model) throws CarKeynotfoundex{
		System.out.println("car ctor start");
		double keyrandom=Math.random()%10;
		if (keyrandom >0.95) {
			carKeyFound=true;
			System.out.println("car key found"+carKeyFound);startTheCar();
		}
		else {//System.out.println("key not found");
		//throw new RuntimeException("CAr key not found");
			throw new CarKeynotfoundex("Car key not found...");
		}
System.out.println("car ctor over");
}
public void startTheCar() {
	System.out.println("car started");}}
class CarKeynotfoundex extends Exception {
	 CarKeynotfoundex(String msg){
	 super(msg);}
}
