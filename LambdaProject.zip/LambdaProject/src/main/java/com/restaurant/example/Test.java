package com.restaurant.example;

public class Test {
	
}
